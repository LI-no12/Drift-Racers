/* Lädt die Stadtdaten von Coburg (Straßen, Gebäude, Gewässer).
   Reihenfolge: 1) data/coburg.json (aus dem Repository)  2) Speicher des Browsers  3) OpenStreetMap (Overpass) mit Zeitlimit.
   Kann ohne echtes Coburg übersprungen werden – dann wird die Ersatz-Stadt gebaut. */
const OSM_CFG={lon0:10.9643,lat0:50.2617,K:.5,dlat:.0145,dlon:.0225,ver:2};
function _idb(){return new Promise((ok,err)=>{const r=indexedDB.open("drift-racers",1);r.onupgradeneeded=()=>r.result.createObjectStore("kv");r.onsuccess=()=>ok(r.result);r.onerror=()=>err(r.error)})}
async function idbGet(k){try{const db=await _idb();return await new Promise((ok,err)=>{const q=db.transaction("kv").objectStore("kv").get(k);q.onsuccess=()=>ok(q.result);q.onerror=()=>err(q.error)})}catch(e){return undefined}}
async function idbSet(k,v){try{const db=await _idb();await new Promise((ok,err)=>{const t=db.transaction("kv","readwrite");t.objectStore("kv").put(v,k);t.oncomplete=ok;t.onerror=()=>err(t.error)})}catch(e){}}
async function ovp2(q,signal){const hosts=["https://overpass-api.de/api/interpreter","https://overpass.kumi.systems/api/interpreter"];let err;
for(const h of hosts){if(signal&&signal.aborted)break;try{const c=new AbortController(),t=setTimeout(()=>c.abort(),30000),ab=()=>c.abort();if(signal)signal.addEventListener("abort",ab);
const r=await fetch(h,{method:"POST",body:"data="+encodeURIComponent(q),signal:c.signal});clearTimeout(t);if(signal)signal.removeEventListener("abort",ab);if(!r.ok)throw new Error(r.status);return (await r.json()).elements}catch(e){err=e}}
throw err||new Error("abgebrochen")}
async function fetchCoburgOsm(progress,signal){const{lon0,lat0,K,dlat,dlon}=OSM_CFG,bb=`${lat0-dlat},${lon0-dlon},${lat0+dlat},${lon0+dlon}`,X=lon=>-(lon-lon0)*71200*K,Z=lat=>(lat-lat0)*111200*K,cv=g=>g.map(p=>[X(p.lon),Z(p.lat)]),say=t=>progress&&progress(t);
say("Straßen …");const rd=await ovp2(`[out:json][timeout:60];way["highway"~"^(motorway|trunk|primary|secondary|tertiary|unclassified|residential|living_street|service|motorway_link|trunk_link|primary_link|secondary_link|tertiary_link)$"](${bb});out geom;`,signal);
say("Gebäude …");const bl=await ovp2(`[out:json][timeout:60];way["building"](${bb});out geom;`,signal);
say("Gewässer …");let wt=[];try{wt=await ovp2(`[out:json][timeout:60];(way["natural"="water"](${bb});way["waterway"~"^(river|stream|canal)$"](${bb}););out geom;`,signal)}catch(e){}
const O={v:OSM_CFG.ver,roads:rd.filter(w=>w.geometry&&w.geometry.length>1).map(w=>({t:w.tags.highway,pts:cv(w.geometry),ids:w.nodes})),
blds:bl.filter(w=>w.geometry&&w.geometry.length>3).map(w=>({pts:cv(w.geometry),h:parseFloat(w.tags.height)||(parseFloat(w.tags["building:levels"])||0)*3.1})),water:[],rivers:[]};
wt.forEach(w=>{if(!w.geometry)return;const p=cv(w.geometry);if(w.tags.waterway)O.rivers.push(p);else if(p.length>3)O.water.push(p)});
return O.roads.length>20?O:null}
async function fetchTimeout(url,ms){const c=new AbortController(),t=setTimeout(()=>c.abort(),ms);try{return await fetch(url,{signal:c.signal})}finally{clearTimeout(t)}}
async function loadCoburg(){const g=id=>document.getElementById(id),ld=g("ld"),msg=g("ldm"),skip=g("skipld"),ctl=new AbortController();let skipped=false;
if(skip)skip.onclick=()=>{skipped=true;ctl.abort()};const done=O=>{if(ld)ld.style.display="none";return O||null};
try{if(msg)msg.textContent="Suche gespeicherte Stadtdaten …";
try{const r=await fetchTimeout("data/coburg.json",6000);if(r.ok){const O=await r.json();if(O&&O.roads&&O.roads.length>20)return done(O)}}catch(e){}
if(skipped)return done(null);
const c=await idbGet("coburg-v"+OSM_CFG.ver);if(c&&c.O&&c.O.roads&&Date.now()-c.t<30*864e5)return done(c.O);
if(skipped)return done(null);
const O=await Promise.race([fetchCoburgOsm(t=>{if(msg)msg.textContent=t+" (beim ersten Start etwa eine halbe Minute)"},ctl.signal),new Promise((_,rej)=>setTimeout(()=>{ctl.abort();rej(new Error("Zeitlimit"))},70000))]);
if(O&&!skipped)idbSet("coburg-v"+OSM_CFG.ver,{t:Date.now(),O});return done(O)}catch(e){return done(null)}}
